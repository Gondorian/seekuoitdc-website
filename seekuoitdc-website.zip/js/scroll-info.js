function getScrolled() {
    var pixelValue = document.body.scrollTop;
    alert("You have scrolled + " pixelValue + "px from top.");
}